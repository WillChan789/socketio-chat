William Chan 30041834
https://github.com/WillChan789/socketio-chat
run "node index.js" on terminal for server, then go to browser client and enter "localhost:3366" and press enter.
